"""
Train ML models for Heart Disease, Diabetes, and Liver Disease.
Uses synthetic/built-in data so no downloads are needed.
Replace with real Kaggle datasets for better accuracy.
"""

import numpy as np
import os
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib

MODEL_DIR = os.path.join(os.path.dirname(__file__), "models")

def make_synthetic(n=600, features=5, seed=42):
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((n, features))
    y = (X[:, 0] + X[:, 1] - X[:, 2] * 0.5 + rng.normal(0, 0.5, n) > 0).astype(int)
    return X, y

def train_one(name, X, y, clf):
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)
    scaler = StandardScaler()
    X_tr = scaler.fit_transform(X_tr)
    X_te = scaler.transform(X_te)
    clf.fit(X_tr, y_tr)
    acc = accuracy_score(y_te, clf.predict(X_te))
    joblib.dump(clf,    os.path.join(MODEL_DIR, f"{name}_model.pkl"))
    joblib.dump(scaler, os.path.join(MODEL_DIR, f"{name}_scaler.pkl"))
    print(f"  ✅ {name.capitalize():10s} accuracy: {acc:.2%}")

def run():
    os.makedirs(MODEL_DIR, exist_ok=True)
    print("\n🔬 Training models...")

    # Heart (5 features)
    X, y = make_synthetic(800, 5, seed=1)
    train_one("heart", X, y, RandomForestClassifier(n_estimators=150, random_state=42))

    # Diabetes (8 features)
    X, y = make_synthetic(800, 8, seed=2)
    train_one("diabetes", X, y, GradientBoostingClassifier(n_estimators=100, random_state=42))

    # Liver (10 features)
    X, y = make_synthetic(800, 10, seed=3)
    train_one("liver", X, y, LogisticRegression(max_iter=1000, random_state=42))

    print("\n🎉 All models saved to ./models/\n")

if __name__ == "__main__":
    run()
