# 🩺 MediPredict — Disease Prediction System

## Quick Start

```bash
# 1. Create & activate virtual environment (Windows)
python -m venv venv
venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Train models (first time only)
python train_models.py

# 4. Start the app
python app.py
```

Then open: **http://127.0.0.1:5000**

---

## 🐛 VS Code Debugging
1. Open this folder in VS Code
2. Press **F5** → select **"Flask: Debug"**
3. Set breakpoints in `app.py` or `train_models.py`

---

## 📁 Project Structure
```
disease_prediction/
├── app.py              ← Flask backend (routes, model loading)
├── train_models.py     ← Train Heart / Diabetes / Liver models
├── requirements.txt
├── models/             ← Saved .pkl files (auto-created)
├── templates/
│   └── index.html      ← Frontend UI
└── .vscode/
    └── launch.json     ← VS Code debug config
```

---

## 🔬 Models Used
| Disease  | Algorithm             | Features |
|----------|-----------------------|----------|
| Heart    | Random Forest         | 5        |
| Diabetes | Gradient Boosting     | 8        |
| Liver    | Logistic Regression   | 10       |

---

## 🚀 Upgrading to Real Datasets
Replace synthetic data in `train_models.py`:
- **Heart**: UCI Heart Disease Dataset (Kaggle)
- **Diabetes**: Pima Indians Diabetes Dataset (Kaggle)
- **Liver**: Indian Liver Patient Dataset (Kaggle)
