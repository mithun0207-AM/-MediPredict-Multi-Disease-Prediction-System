"""
Disease Prediction - Flask Backend
Run: python app.py
Then open: http://127.0.0.1:5000
"""

from flask import Flask, render_template, request, jsonify
import joblib, numpy as np, os, json

app = Flask(__name__)

# ── Load models if they exist ──────────────────────────────────────
MODELS = {}

def load_models():
    model_dir = os.path.join(os.path.dirname(__file__), "models")
    for name in ["heart", "diabetes", "liver"]:
        mpath = os.path.join(model_dir, f"{name}_model.pkl")
        spath = os.path.join(model_dir, f"{name}_scaler.pkl")
        if os.path.exists(mpath):
            MODELS[name] = {
                "model":  joblib.load(mpath),
                "scaler": joblib.load(spath) if os.path.exists(spath) else None
            }
    print(f"✅ Loaded models: {list(MODELS.keys())}")

load_models()

# ── Routes ─────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/train", methods=["POST"])
def train():
    """Train all models on demand."""
    try:
        import train_models
        train_models.run()
        load_models()
        return jsonify({"status": "ok", "models": list(MODELS.keys())})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/predict", methods=["POST"])
def predict():
    data     = request.get_json()
    disease  = data.get("disease", "heart")
    features = data.get("features", [])

    if disease not in MODELS:
        return jsonify({"error": f"Model '{disease}' not found. Click Train first."}), 400

    try:
        arr = np.array(features, dtype=float).reshape(1, -1)
        entry = MODELS[disease]
        if entry["scaler"]:
            arr = entry["scaler"].transform(arr)
        pred  = entry["model"].predict(arr)[0]
        proba = entry["model"].predict_proba(arr)[0].max()

        labels = {
            "heart":    ("⚠️ Heart Disease Risk Detected",   "✅ Low Heart Disease Risk"),
            "diabetes": ("⚠️ Diabetes Risk Detected",        "✅ Low Diabetes Risk"),
            "liver":    ("⚠️ Liver Disease Risk Detected",   "✅ Low Liver Disease Risk"),
        }
        pos_label, neg_label = labels.get(disease, ("Positive", "Negative"))
        result = pos_label if int(pred) == 1 else neg_label

        return jsonify({
            "prediction":  result,
            "confidence":  f"{proba * 100:.1f}%",
            "is_positive": int(pred) == 1
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    print("\n🩺 Disease Prediction System starting...")
    print("🌐 Open: http://127.0.0.1:5000\n")
    app.run(debug=True)
